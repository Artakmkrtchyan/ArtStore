<!-- <!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css.css">
    <title>Choose Option</title>
  </head>
  <body>
<div class="container">

<div class="choose">
<button><a href="/home">Get</a></button>
<button><a href="/add">Add</a></button>
</div>



</div>
  </body>
</html> -->
<?php /**PATH C:\OpenServer\domains\laravel-new\resources\views/welcome.blade.php ENDPATH**/ ?>