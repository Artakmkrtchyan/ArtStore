<!doctype html>
<html lang="zxx">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
  <title>ArtStore</title>

  <link rel="stylesheet" href="/style.css">

  <link href="//fonts.googleapis.com/css?family=Oswald:300,400,500,600&display=swap" rel="stylesheet">
  <link href="//fonts.googleapis.com/css?family=Lato:300,300i,400,400i,700,900&display=swap" rel="stylesheet">


</head>
<body>

<section class="w3l-banner-slider-main">
	<div class="top-header-content">
		<header class="tophny-header">
			<div class="container-fluid">

			</div>
			<nav class="navbar navbar-expand-lg navbar-light">
				<div class="container-fluid serarc-fluid">
					<a class="navbar-brand" href="/home">
						Art<span class="lohny">S</span>tore</a>
					<div class="search-right">

						<a href="#search" title="search"><span class="fa fa-search mr-2" aria-hidden="true"></span>
							<span class="search-text">Search here</span></a>

						<div id="search" class="pop-overlay">
							<div class="popup">

								<form action="/search" method="post" id="myForm" class="search-box">
									<?php echo csrf_field(); ?>
									<input type="text" placeholder="Keyword" id="main_input" name="search" required="required"
										autofocus="">
									<button type="submit" class="btn" id="button">Search</button>
								</form>

							</div>
							<a class="close" href="#">×</a>
						</div>
					</div>







					<button class="navbar-toggler" type="button" data-toggle="collapse"
						data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
						aria-expanded="false" aria-label="Toggle navigation">
						<span class="navbar-toggler-icon fa fa-bars"> </span>
					</button>
					<div class="collapse navbar-collapse" id="navbarSupportedContent">
						<ul class="navbar-nav ml-auto">
							<li class="nav-item active">
								<a class="nav-link" href="/home">Home</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" href="/add">Add Product</a>
							</li>
						</ul>

					</div>
				</div>
			</nav>

		</header>
		<div class="bannerhny-content">


			<div class="content-baner-inf">
				<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
					<ol class="carousel-indicators">
						<li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
						<li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
						<li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
						<li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
					</ol>
					<div class="carousel-inner">
						<div class="carousel-item active">
							<div class="container">
								<div class="carousel-caption">
									<h3>Women's
										Fashion
										<br>50% Off</h3>


								</div>
							</div>
						</div>
						<div class="carousel-item item2">
							<div class="container">
								<div class="carousel-caption">
									<h3>Men's
										Fashion
										<br>60% Off</h3>


								</div>
							</div>
						</div>
						<div class="carousel-item item3">
							<div class="container">
								<div class="carousel-caption">
									<h3>Women's
										Fashion
										<br>50% Off</h3>


								</div>
							</div>
						</div>
						<div class="carousel-item item4">
							<div class="container">
								<div class="carousel-caption">
									<h3>Men's
										Fashion
										<br>60% Off</h3>
									<a href="#" class="shop-button btn">
										Shop Now
									</a>
								</div>
							</div>
						</div>
					</div>


				</div>
			</div>

			<div class="right-banner">
				<div class="right-1">
					<h4>
						Men's
						Fashion
						<br>50% Off</h4>
				</div>
			</div>

		</div>

</section>





<section class="w3l-grids-hny-2">
	<div class="grids-hny-2-mian py-5">
		<div class="container py-lg-5">

			<h3 class="hny-title mb-0 text-center">Shop With <span>Us</span></h3>
			<p class="mb-4 text-center">Handpicked Favourites just for you</p>
			<div class="welcome-grids row mt-5">


	<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-lg-2 col-md-4 col-6 welcome-image">

						<div class="boxhny13">
								<a href="/filter/<?php echo e($categorie->id); ?>" id="category_name">
										<img src="<?php echo e($categorie->image); ?>" class="img-fluid" alt="" />

								<div class="boxhny-content">
									<h3 class="title"><?php echo e($categorie->name); ?></h3>
								</div>
							</a>
						</div>
						<h4><a href="/filter/<?php echo e($categorie->id); ?>" id="category_name"><?php echo e($categorie->name); ?></a></h4>

				</div>
	 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			</div>

		</div>
	</div>
</section>




<section class="w3l-ecommerce-main">
	<div class="ecom-contenthny py-5">
		<div class="container py-lg-5">
			<h3 class="hny-title mb-0 text-center">Shop With <span>Us</span></h3>
			<p class="text-center">Handpicked Favourites just for you</p>

			<div class="ecom-products-grids row mt-lg-5 mt-3">

<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-lg-3 col-6 product-incfhny mt-4">
					<div class="product-grid2 transmitv">
						<div class="product-image2">
							<a href="/product_once/<?php echo e($product->id); ?>"><img class="pic-1 img-fluid" src="<?php echo e($product->image); ?>"></a>
							<a href="/product_once/<?php echo e($product->id); ?>"><img class="pic-2 img-fluid" src="<?php echo e($product->image); ?>"></a>
							<ul class="social">
									<li><a href="#" data-tip="Quick View"><span class="fa fa-eye"></span></a></li>

									<li><a href="#" data-tip="Add to Cart"><span class="fa fa-shopping-bag"></span></a>
									</li>
							</ul>
							<div class="transmitv single-item">
							<form action="#" method="post">
									<input type="hidden" name="cmd" value="_cart">
									<input type="hidden" name="add" value="1">
									<input type="hidden" name="transmitv_item" value="Women Maroon Top">
									<input type="hidden" name="amount" value="899.99">
								<a href="/product_once/<?php echo e($product->id); ?>" class="transmitv-cart ptransmitv-cart add-to-cart">	Buy Now	</a>
								</form>
							</div>
						</div>
						<div class="product-content">
							<h3 class="title"><a href="/product_once/<?php echo e($product->id); ?>" id="product_name"><?php echo e($product->name); ?></a></h3>
							<span class="price"><a href="/product_once/<?php echo e($product->id); ?>" id="a"><?php echo e($product->price. ' $'); ?></a></span>
						</div>
					</div>
				</div>

 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			</div>

		</div>
	</div>
</section>

<section class="w3l-content-w-photo-6">

	  <div class="content-photo-6-mian py-5">
			 <div class="container py-lg-5">
					<div class="align-photo-6-inf-cols row">

						<div class="photo-6-inf-right col-lg-6">
								<h3 class="hny-title text-left">All Branded Men's Suits are Flat <span>30% Discount</span></h3>
								<p>Visit our shop to see amazing creations from our designers.</p>
								<a href="#" class="read-more btn">
										Shop Now
								</a>
						</div>
						<div class="photo-6-inf-left col-lg-6">
								<img src="/images/1.jpg" class="img-fluid" alt="">
						</div>
					</div>
				 </div>
			 </div>
	 </section>


<section class="w3l-content-5">

	<div class="content-5-main">
		<div class="container">
			<div class="content-info-in row">
				<div class="content-gd col-md-6 offset-lg-3 text-center">
					<h3 class="hny-title two">
						Tons of Products & Options to
						<span>change</span></h3>
					<p>Ea consequuntur illum facere aperiam sequi optio consectetur adipisicing elitFuga, suscipit totam
						animi consequatur saepe blanditiis.Lorem ipsum dolor sit amet,Ea consequuntur illum facere
						aperiam sequi optio consectetur adipisicing elit..</p>
					<a href="#" class="read-more-btn2 btn">
						Shop Now
					</a>

				</div>

			</div>

		</div>
	</div>
</section>



  <section class="w3l-footer-22">
      <div class="footer-hny py-5">
          <div class="container py-lg-5">
              <div class="text-txt ">
                  <div class="left-side col-lg-4">
                      <h3><a class="logo-footer" href="/home">
                            Art<span class="lohny">S</span>tore</a></h3>
                      <p>Lorem ipsum dolor sit amet,Ea consequuntur illum facere aperiam sequi optio consectetur.Vivamus
                          a ligula quam. Ut blandit eu leo non suscipit. </p>
                      <ul class="social-footerhny mt-lg-5 mt-4">

                          <li><a class="facebook" href="#"><span class="fa fa-facebook" aria-hidden="true"></span></a>
                          </li>
                          <li><a class="twitter" href="#"><span class="fa fa-twitter" aria-hidden="true"></span></a>
                          </li>
                          <li><a class="google" href="#"><span class="fa fa-google-plus" aria-hidden="true"></span></a>
                          </li>
                          <li><a class="instagram" href="#"><span class="fa fa-instagram" aria-hidden="true"></span></a>
                          </li>
                      </ul> <br>
                      <div class="sub-two-right">
                          <h6>We accept:</h6>
                          <ul>
                              <li><a class="pay-method" href="#"><span class="fa fa-cc-visa"
                                          aria-hidden="true"></span></a>
                              </li>
                              <li><a class="pay-method" href="#"><span class="fa fa-cc-mastercard"
                                          aria-hidden="true"></span></a>
                              </li>
                              <li><a class="pay-method" href="#"><span class="fa fa-cc-paypal"
                                          aria-hidden="true"></span></a>
                              </li>
                              <li><a class="pay-method" href="#"><span class="fa fa-cc-amex"
                                          aria-hidden="true"></span></a>
                              </li>
                          </ul>
                      </div>
                  </div>

                  <div class="right-side col-lg-8 pl-lg-5">
                      <h4>Women's Day Special Offer
                        All Branded Sandals are Flat 50% Discount</h4>
                      <div class="sub-columns">


                      </div>
                  </div>
              </div>
              <div class="below-section row">
                  <div class="columns col-lg-6">
                      <ul class="jst-link">
                          <li><a href="/home">Home </a> </li>
                          <li><a href="/add">Add Product</a></li>
                      </ul>
                  </div>
                  <div class="columns col-lg-6 text-lg-right">
                      <p>© 2020 ArtStore. All rights reserved.</p>
                  </div>
                  <button onclick="topFunction()" id="movetop" title="Go to top">
                      <span class="fa fa-angle-double-up"></span>
                  </button>
              </div>
          </div>
      </div>

      <script>

          window.onscroll = function () {
              scrollFunction()
          };

          function scrollFunction() {
              if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
                  document.getElementById("movetop").style.display = "block";
              } else {
                  document.getElementById("movetop").style.display = "none";
              }
          }

          function topFunction() {
              document.body.scrollTop = 0;
              document.documentElement.scrollTop = 0;
          }
      </script>

  </section>


  </body>

  </html>

<script src="assets/js/jquery-3.3.1.min.js"></script>
<script src="assets/js/jquery-2.1.4.min.js"></script>

<script>
		$(document).ready(function () {
			$(".button-log a").click(function () {
				$(".overlay-login").fadeToggle(200);
				$(this).toggleClass('btn-open').toggleClass('btn-close');
			});
		});
		$('.overlay-close1').on('click', function () {
			$(".overlay-login").fadeToggle(200);
			$(".button-log a").toggleClass('btn-open').toggleClass('btn-close');
			open = false;
		});
  </script>

	<script>
		$('#customerhnyCarousel').carousel({
				interval: 5000
    });
  </script>

 <script src="assets/js/minicart.js"></script>
 <script>
     transmitv.render();

     transmitv.cart.on('transmitv_checkout', function (evt) {
         var items, len, i;

         if (this.subtotal() > 0) {
             items = this.items();

             for (i = 0, len = items.length; i < len; i++) {}
         }
     });
 </script>
<script src="assets/js/jquery.magnific-popup.js"></script>

<script>
  $(document).ready(function () {
    $('.popup-with-zoom-anim').magnificPopup({
      type: 'inline',
      fixedContentPos: false,
      fixedBgPos: true,
      overflowY: 'auto',
      closeBtnInside: true,
      preloader: false,
      midClick: true,
      removalDelay: 300,
      mainClass: 'my-mfp-zoom-in'
    });

  });
</script>

<script>
  $(function () {
    $('.navbar-toggler').click(function () {
      $('body').toggleClass('noscroll');
    })
  });
</script>

<script src="assets/js/bootstrap.min.js"></script>
<?php /**PATH C:\OpenServer\domains\laravel-new\resources\views/general/home.blade.php ENDPATH**/ ?>