<h1>
    THIS IS <?php echo e($data['name']); ?>

</h1>
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div>

        <label for="product_name">Product</label>
        <span id="product_name"><?php echo e($product->id . ' ' . $product->name); ?></span>
        <span id="product_name"><?php echo e($product->price); ?></span>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\OSPanel\domains\laravel-new\resources\views/general/home.blade.php ENDPATH**/ ?>