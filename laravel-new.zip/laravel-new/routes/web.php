<?php

use Illuminate\Support\Facades\Route;

Route::get('/home',[App\Http\Controllers\GeneralController::class,'homeIndex']);
Route::get('/add',[App\Http\Controllers\GeneralController::class,'add_product']);
Route::post('/create',[App\Http\Controllers\FileController::class,'create_product']);
Route::post('/search',[App\Http\Controllers\GeneralController::class,'search'])->name('searchProduct');
Route::get('/filter/{id}',[App\Http\Controllers\GeneralController::class,'filter']);
Route::get('/product_page',[App\Http\Controllers\GeneralController::class,'product_page']);
Route::get('/product_once/{id}',[App\Http\Controllers\GeneralController::class,'product_item']);
Route::get('/edit/{id}',[App\Http\Controllers\GeneralController::class,'editProduct']);
Route::post('/edit_info/{id}',[App\Http\Controllers\FileController::class,'edit_info']);
Route::post('/delete/{id}',[App\Http\Controllers\GeneralController::class,'delete_product']);


Route::get('/', function () {
     return redirect('/home');
});
