<!doctype html>
<html lang="zxx">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="csrf-token" content="{{ csrf_token() }}" />
  <title>ArtStore</title>
  <link rel="stylesheet" href="/style.css">
  <link href="//fonts.googleapis.com/css?family=Oswald:300,400,500,600&display=swap" rel="stylesheet">
  <link href="//fonts.googleapis.com/css?family=Lato:300,300i,400,400i,700,900&display=swap" rel="stylesheet">
</head>
<body>

<section class="w3l-banner-slider-main">
	<div class="top-header-content">
		<header class="tophny-header aaa">
			<div class="container-fluid">
			</div>
			<nav class="navbar navbar-expand-lg navbar-light">
				<div class="container-fluid serarc-fluid">
					<a class="navbar-brand" href="/home">
						Art<span class="lohny">S</span>tore</a>
					<button class="navbar-toggler" type="button" data-toggle="collapse"
						data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
						aria-expanded="false" aria-label="Toggle navigation">
						<span class="navbar-toggler-icon fa fa-bars"> </span>
					</button>
					<div class="collapse navbar-collapse" id="navbarSupportedContent">
						<ul class="navbar-nav ml-auto">
							<li class="nav-item active">
								<a class="nav-link" href="/home">Home</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" href="/add">Add Product</a>
							</li>
						</ul>

					</div>
				</div>
			</nav>
		</header>
	</div>
</section>
<div class="prosto">

</div>

	<div class="add_product_block">
		<h2>Add Product</h2>
		 <form action="/create" method="post" id="myForm" enctype="multipart/form-data">
	    @csrf
			<div class="add_product_info">
	    <input class="in" type="text" name="add_name" id="add_name" placeholder="Write Name">
	    <input class="in" type="text" name="add_price" id="add_price" placeholder="Write Price">
	    <input class="in" id="in-file" type="file" name="file" value="" placeholder="aaaa">
	    <input class="in" type="text" name="add_category" id="add_category" placeholder="Write Category">
	<div class="a-but">
		<a class="back" href="/home">Back</a>
		<button id="button" type="submit">Add</button>
	</div>
			</div>
		</form>
		</div>
<section class="w3l-footer-22">
		<div class="footer-hny py-5">
				<div class="container py-lg-5">
						<div class="text-txt ">
								<div class="left-side col-lg-4">
										<h3><a class="logo-footer" href="/home">
													Art<span class="lohny">S</span>tore</a></h3>
										<p>Lorem ipsum dolor sit amet,Ea consequuntur illum facere aperiam sequi optio consectetur.Vivamus
												a ligula quam. Ut blandit eu leo non suscipit. </p>
										<ul class="social-footerhny mt-lg-5 mt-4">
												<li><a class="facebook" href="#"><span class="fa fa-facebook" aria-hidden="true"></span></a>
												</li>
												<li><a class="twitter" href="#"><span class="fa fa-twitter" aria-hidden="true"></span></a>
												</li>
												<li><a class="google" href="#"><span class="fa fa-google-plus" aria-hidden="true"></span></a>
												</li>
												<li><a class="instagram" href="#"><span class="fa fa-instagram" aria-hidden="true"></span></a>
												</li>
										</ul> <br>
										<div class="sub-two-right">
												<h6>We accept:</h6>
												<ul>
														<li><a class="pay-method" href="#"><span class="fa fa-cc-visa"
																				aria-hidden="true"></span></a>
														</li>
														<li><a class="pay-method" href="#"><span class="fa fa-cc-mastercard"
																				aria-hidden="true"></span></a>
														</li>
														<li><a class="pay-method" href="#"><span class="fa fa-cc-paypal"
																				aria-hidden="true"></span></a>
														</li>
														<li><a class="pay-method" href="#"><span class="fa fa-cc-amex"
																				aria-hidden="true"></span></a>
														</li>
												</ul>
										</div>
								</div>

								<div class="right-side col-lg-8 pl-lg-5">
										<h4>Women's Day Special Offer
											All Branded Sandals are Flat 50% Discount</h4>
										<div class="sub-columns">
										</div>
								</div>
						</div>
						<div class="below-section row">
								<div class="columns col-lg-6">
										<ul class="jst-link">
												<li><a href="/home">Home </a> </li>
												<li><a href="/add">Add Product</a></li>
										</ul>
								</div>
								<div class="columns col-lg-6 text-lg-right">
										<p>© 2020 ArtStore. All rights reserved.</p>
								</div>
								<button onclick="topFunction()" id="movetop" title="Go to top">
										<span class="fa fa-angle-double-up"></span>
								</button>
						</div>
				</div>
		</div>

		<script>

				window.onscroll = function () {
						scrollFunction()
				};

				function scrollFunction() {
						if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
								document.getElementById("movetop").style.display = "block";
						} else {
								document.getElementById("movetop").style.display = "none";
						}
				}

				function topFunction() {
						document.body.scrollTop = 0;
						document.documentElement.scrollTop = 0;
				}
		</script>

</section>
