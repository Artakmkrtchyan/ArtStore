<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
       
    	DB::insert('insert into products (name,price,type) values (?,?,?)',['Hakust',200,'XL']);
       	//$affected = DB::update('update products set name = ? where name = ?',['mterq','hakust']);
        // $this->call(UserSeeder::class);
    }
}
