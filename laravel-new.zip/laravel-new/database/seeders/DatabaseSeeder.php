<?php

namespace Database\Seeders;

use Carbon\Carbon;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
//        DB::insert('insert into products (name, price,model,created_at,updated_at) values (?, ?, ?,?,?)', ['hagust', 200, 'test',Carbon::now(),Carbon::tomorrow()]);
//        $affected = DB::update('update products set name = ? where name = ?', ['mterq','hagust']);
//        DB::table('poducts')->get();
//        DB::transaction(function () {
//            DB::table('users')->update(['votes' => 1]);
//
//            DB::table('posts')->delete();
//        });

         \App\Models\User::factory(50)->create();
    }
}
