<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::insert('insert into products (name, price,model,created_at,updated_at) values (?, ?, ?,?,?)', ['hagust', 200, 'test',Carbon::now(),Carbon::tomorrow()]);

    }
}
