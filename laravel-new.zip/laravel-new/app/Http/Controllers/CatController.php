<?php

namespace App\Http\Controllers;
use App\Models\Category;
use Illuminate\Http\Request;

class CatController extends Controller
{
      public function cat() {
          




      }



      public function addCategory() {
         return response()->json([
              'success' => true
          ]);
      }
}
