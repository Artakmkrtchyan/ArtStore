<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Category;
use Illuminate\Http\Request;

class FileController extends Controller
{


  public function create_product(Request $request) {

    $review = new Product();
    $review->name=$request->input('add_name');
    $review->price=$request->input('add_price');
    $review->cat_prod=$request->input('add_category');
    $filePath = $request->file->storeAs('/images',time() . '.' . $request->file->getClientOriginalExtension());
    $review->image='/' . $filePath;
    $review->save();

       return redirect('/home');
    }


  public function edit_info(Request $request,$id) {
    $product = Product::find($id)->load('category');

    $product->name = $request->input('add_name');
    $product->price = $request->input('add_price');
    $product->cat_prod = $request->input('add_category');
    $filePath = $request->file->storeAs('/images/',time() . '.' . $request->file->getClientOriginalExtension());
    $product->image = '/' . $filePath;
    $product->save();
       return view('general.product_page',compact('product'));
  }
}
