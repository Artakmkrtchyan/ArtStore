<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Category;
use Illuminate\Http\Request;

class GeneralController extends Controller
{
    public function homeIndex() {

       $products = Product::all();
       $categories = Category::all();

        return view('general.home',compact('categories','products'));
    }

    public function search(Request $request) {
      $categories = Category::all();
      $search = ($request->input('search'));

      $products = Product::where('name','like','%' . $search . '%')->get();
        return view('general.home',compact('categories','products'));
    }


    public function filter(Request $request,$id) {
      $category = Category::where('id',$id)->first()->load('products');
      $categories = Category::all();
      $products = $category->products;
      return view('general.home',compact('categories','products'));

    }


  public function add_product(Request $request) {

       return view('general.add');
    }


      public function product_page() {

            return view('general.product_page');
        }




        public function product_item(Request $request,$id) {

           $product = Product::find($id)->load('category');
              return view('general.product_page',compact('product'));
          }


        public function editProduct(Request $request,$id) {
          $product = Product::find($id)->load('category');
             return view('general.edit',compact('product'));
        }

        public function delete_product($id)
        {
        $product = Product::find($id)->delete();
               return redirect('/home');
        }

public function addProduct() {
   return response()->json([
        'success' => true
    ]);
}
}
